function openSearchBar() {
    $("#searchForStuff").css("display","block");
    $("#openSearchBar").css("display","none");
}

function closeSearchBar() {
    $("#openSearchBar").css("display","block");
    $("#searchForStuff").css("display","none");
}
